(function() { // <-- It's an IIFE
var app = angular.module("megaApp", ["ngRoute"]); // create the module

// Angular with auto-"magically" inject the $routeProvider object here.
app.config(function($routeProvider) {
    // The URL hash paths below (ex: "/madlib", "/band") must match exactly
    // with the URL hash in the browser, including the "/" prefix.
    $routeProvider.when("/madlib", {
        // This template will be used when the URL has "#/madlib" hash.
        // Since this template doesn't need a controller, we don't have
        // to specify one.
        templateUrl: "views/madlib.html"
    });
    $routeProvider.when("/band", {
        // This template and controller will be used when the URL has
        // "#/band" hash.
        templateUrl: "views/band-members.html",
        controller: "bandMembersController"
    });
    $routeProvider.otherwise({
        // This template will be used when the the URL hash doesn't match
        // either of the above.
        template: "Please select one of the links above."
    });
});

})();
