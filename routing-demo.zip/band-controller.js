(function() { // <-- IIFE
// Because we don't pass the second ([]) parameter, angular.module gets the
// module we made earlier rather than creating one.
var app = angular.module("megaApp");

// Define a controller named 'bandMembersController'
app.controller("bandMembersController", function($scope) {
    // Add a variable called "bandMembers" to the scope.
    $scope.bandMembers = [ "Benjamin Gibbard", "Jimmy Tamborello", "Jenny Lewis", "Laura Burhenn" ];
});

})();
