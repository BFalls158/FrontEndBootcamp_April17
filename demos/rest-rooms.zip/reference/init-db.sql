CREATE TABLE Rooms (
    id SERIAL UNIQUE PRIMARY KEY,
    name VARCHAR(40),
    capacity INT,
    available BOOLEAN
);

INSERT INTO Rooms (name, capacity, available)
VALUES ('Sun Room', 30, FALSE);
INSERT INTO Rooms (name, capacity, available)
VALUES ('Green Room', 20, FALSE);
INSERT INTO Rooms (name, capacity, available)
VALUES ('Penthouse', 100, TRUE);
