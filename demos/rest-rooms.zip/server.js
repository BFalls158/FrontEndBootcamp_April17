var express = require('express');
var bodyParser = require('body-parser');
var pg = require('pg');

var app = express();
// This allows us to accept JSON bodies in POSTs and PUTs.
app.use(bodyParser.json());

// Set up a connection pool with wich to access the database in all the
// operations below.
var pool = new pg.Pool({
    user: "postgres",
    password: "****",
    host: "localhost",
    port: 5432,
    database: "postgres",
    ssl: false
});

// GET /rooms - responds with an array of all rooms in the database.
app.get('/rooms', function(req, res) {
    pool.query("SELECT * FROM Rooms").then(function(result) {
        res.send(result.rows);
    }).catch(errorCallback(res));
});

// POST /rooms - adds an room to the database. The rooms name and price
// are available as JSON from the request body.
app.post('/rooms', function(req, res) {
    var room = req.body; // <-- Get the parsed JSON body
    var sql = "INSERT INTO Rooms(name, capacity, available) " +
              "VALUES ($1::text, $2::int, $3::boolean)";
    var values = [room.name, room.capacity, room.available];

    pool.query(sql, values).then(function() {
        res.status(201); // 201 Created
        res.send("INSERTED");
    }).catch(errorCallback(res));
});

// GET /rooms/{ID} - responds with the one matching room from the database.
app.get('/rooms/:id', function(req, res) {
    var id = req.params.id; // <-- This gets the :id part of the URL
    pool.query("SELECT * FROM Rooms WHERE id = $1::int", [id]).then(function(result) {
        if (result.rowCount === 0) {
            res.status(404); // 404 Not Found
            res.send("NOT FOUND");
        } else {
            // Return the first result. There should only be one.
            res.send(result.rows[0]);
        }
    }).catch(errorCallback(res));
});

// PUT /rooms/{ID} - modify a room in the database. The room is
// selected via the {ID} part of the URL.
app.put('/rooms/:id', function(req, res) {
    var id = req.params.id; // <-- This gets the :id part of the URL
    var room = req.body; // <-- Get the parsed JSON body
    var sql = "UPDATE Rooms SET name = $2::text, capacity = $3::int, available = $4::boolean " +
              "WHERE id = $1::int";
    var values = [id, room.name, room.capacity, room.available];

    pool.query(sql, values).then(function() {
        res.send("UPDATED");
    }).catch(errorCallback(res));
});

// DELETE /rooms/{ID} - delete an room from the database. The room is
// selected via the {ID} part of the URL.
app.delete('/rooms/:id', function(req, res) {
    var id = req.params.id; // <-- This gets the :id part of the URL
    pool.query("DELETE FROM Rooms WHERE id = $1::int", [id]).then(function() {
        res.send("DELETED");
    }).catch(errorCallback(res));
});

function errorCallback(res) {
    return function(err) {
        console.log(err);
        res.status(500); // 500 Server Error
        res.send("ERROR!");
    }
}

var port = process.env.PORT || 5000;
app.listen(port, function () {
  console.log('JSON Server is running on ' + port);
});
