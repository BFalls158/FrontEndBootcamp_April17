angular.module("testingDemoModule")
.factory("weatherService", function($http, $q) {

    var apiKey = "6223b2f5321ee9e1";

    function extractTemperature(response) {
        return response.data.current_observation.temp_f;
    }

    function getWeatherAt(locationString) {
        var loc = parseCityState(locationString);
        if (!loc) {
            return $q.reject(locationString);
        }
        return $http({
            method: 'GET',
            url: 'http://api.wunderground.com/api/' + apiKey + '/conditions/q/' + encodeURIComponent(loc.state) + '/' + encodeURIComponent(loc.city) + '.json'
        });
    }

    function parseCityState(location) {
        if (!location) {
            return null;
        }
        var parts = location.trim().split(",");
        if (parts.length != 2) {
            return null;
        }
        return {
            city: parts[0],
            state: parts[1]
        };
    }

    return {
        getTemperatureAt: function(location) {
            return getWeatherAt(location).then(extractTemperature);
        }
    };
});
