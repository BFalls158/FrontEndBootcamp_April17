// This controller is a bit complicated because it makes use of promises with
// the weatherService.
angular.module("testingDemoModule")
.controller("whatToWearAtLocationController", function($scope, whatToWearService, weatherService) {
    $scope.eventType = "casual";

    $scope.temperature = null;
    $scope.output = "Waiting for temperature...";

    $scope.updateEventType = function() {
        updateOutput();
    };
    $scope.updateLocation = function() {
        // Weather Service returns a promise. It may take some time to resolve.
        weatherService.getTemperatureAt($scope.location).then(function(temp) {
            $scope.temperature = temp;
            updateOutput();
        }).catch(function() {
            $scope.temperature = null;
            updateOutput();
        });
    };

    function updateOutput() {
        $scope.output = whatToWearService.describeAppropriateClothing($scope.temperature, $scope.eventType);
    }

});
