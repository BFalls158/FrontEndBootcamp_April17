angular.module("testingDemoModule")
.factory("whatToWearService", function($http) {

    function getOuterwear(temperature) {
        if (temperature < 54) {
            return "a coat";
        } else if (temperature > 70) {
            return "no jacket";
        } else {
            return "a jacket";
        }
    }

    function getOutfit(eventType) {
        switch (eventType) {
        case "casual":
            return "something comfy";
        case "semi-formal":
            return "a polo";
        case "formal":
            return "a suit";
        }
    }

    return {
        describeAppropriateClothing: function(temperature, eventType) {
            if (angular.isUndefined(temperature) || temperature === null) {
                return "Waiting for temperature..."
            } else {
                return "Wear " + getOutfit(eventType) + " and " + getOuterwear(temperature) + ".";
            }
        },
        getOutfit: getOutfit,
        getOuterwear: getOuterwear
    }

});
