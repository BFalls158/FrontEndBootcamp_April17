angular.module("testingDemoModule")
.controller("whatToWearController", function($scope, whatToWearService) {
    $scope.eventType = "casual";
    $scope.temperature = 72;
    updateOutput();

    $scope.updateEventType = function() {
        updateOutput();
    };
    $scope.updateTemperature = function() {
        updateOutput();
    };

    function updateOutput() {
        $scope.output = whatToWearService.describeAppropriateClothing($scope.temperature, $scope.eventType);
    }

});
