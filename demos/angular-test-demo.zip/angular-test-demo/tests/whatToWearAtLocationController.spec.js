// This test is a bit complicated because it makes use of promises with
// the weatherService.
describe("whatToWearAtLocationController", function() {

    beforeEach(module("testingDemoModule"));

    var mockTemperature = 0;
    var whatToWearController, whatToWearService, $scope, $rootScope, $q;

    var mockWeatherService = {
        getTemperatureAt: function() {
            var deferred = $q.defer();
            deferred.resolve(mockTemperature);
            return deferred.promise;
        }
    }

    beforeEach(inject(function(_whatToWearService_, $controller, _$rootScope_, _$q_) {
        whatToWearService = _whatToWearService_;
        $scope = {};
        $rootScope = _$rootScope_;
        $q = _$q_;
        whatToWearController = $controller('whatToWearAtLocationController', {
            $scope: $scope,
            whatToWearService: whatToWearService,
            weatherService: mockWeatherService
        });
    }));

    it("starts out waiting for temperature", function() {
        expect($scope.output).toBe("Waiting for temperature...");
    });

    it("updates output when temperature changes", function() {
        mockTemperature = 75;
        $scope.updateLocation();
        $rootScope.$digest();
        expect($scope.output).toBe("Wear something comfy and no jacket.");
    });

    it("updates output when event type changes", function() {
        // setup
        mockTemperature = 50;
        $scope.updateLocation();
        $rootScope.$digest();

        // action
        $scope.eventType = "formal";
        $scope.updateEventType();

        // verify
        expect($scope.output).toBe("Wear a suit and a coat.");
    });

});
