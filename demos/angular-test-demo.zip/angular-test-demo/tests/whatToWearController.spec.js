describe("whatToWearController", function() {

    // This tells it which module we're testing.
    beforeEach(module("testingDemoModule"));

    // Declare variables here that need to be shared between all the funcitons below.
    var whatToWearController, whatToWearService, $scope;

    // use inject() to grab angular dependencies
    beforeEach(inject(function(_whatToWearService_, $controller) {
        whatToWearService = _whatToWearService_; // this is the real whatToWearService.
        $scope = {}; // Scope starts out empty
        // Create the controller. Specify the dependencies to inject.
        whatToWearController = $controller('whatToWearController', {
            $scope: $scope,
            whatToWearService: whatToWearService
        });
    }));

    it("starts out with default", function() {
        expect($scope.output).toBe("Wear something comfy and no jacket.");
    });

    it("updates output when temperature changes", function() {
        $scope.temperature = 60;
        $scope.updateTemperature();
        expect($scope.output).toBe("Wear something comfy and a jacket.");
    });

    it("updates output when event type changes", function() {
        $scope.eventType = 'formal';
        $scope.updateEventType();
        expect($scope.output).toBe("Wear a suit and no jacket.");
    });

});
