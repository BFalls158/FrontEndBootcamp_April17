// Step 1: Start with a describe() that indicates what service we're testing.
// Everything else goes inside this function block.
describe("whatToWearService", function() {

    // Step 2: This tells it which module we're testing.
    beforeEach(module("testingDemoModule"));

    // Declare variables here that need to be shared between all the funcitons below.
    var whatToWearService;

    // Step 3: use inject() to grab angular dependencies
    // Here the dependencies should be surrounded by underscores.
    beforeEach(inject(function(_whatToWearService_) {
        // Assign each injected dependency to a variable declared above.
        whatToWearService = _whatToWearService_; // this is the real whatToWearService.
    }));

    // Step 4: Each test case calls a method on the service and asserts that
    // it returns the right thing.
    it("returns coat at top of temp. range", function() {
        // Call getOuterwear with 53 degrees. It should return "a coat".
        expect(whatToWearService.getOuterwear(53)).toBe("a coat");
    });

    // All the 'it()'s go inside the describe(). Each one should have an English
    // description that is a comment to help humans identify that test.
    it("returns jacket at bottom of temp. range", function() {
        expect(whatToWearService.getOuterwear(54)).toBe("a jacket");
    });

    it("returns jacket at top of temp. range", function() {
        expect(whatToWearService.getOuterwear(70)).toBe("a jacket");
    });

    it("returns no jacket at bottom of temp. range", function() {
        expect(whatToWearService.getOuterwear(71)).toBe("no jacket");
    });

    it("returns something comfy for casual", function() {
        expect(whatToWearService.getOutfit("casual")).toBe("something comfy");
    });

    it("returns a polo for semi-formal", function() {
        expect(whatToWearService.getOutfit("semi-formal")).toBe("a polo");
    });

    it("returns a suit for formal", function() {
        expect(whatToWearService.getOutfit("formal")).toBe("a suit");
    });

    it("constructs description from parts", function() {
        expect(whatToWearService.describeAppropriateClothing(60, "formal")).toBe("Wear a suit and a jacket.");
    });

    it("waits for temperature when not provided", function() {
        // You're allowed to do multiple assertions in the same "it()", but
        // more often we just do one.
        expect(whatToWearService.describeAppropriateClothing(null, "formal")).toBe("Waiting for temperature...");
        expect(whatToWearService.describeAppropriateClothing(undefined, "formal")).toBe("Waiting for temperature...");
    });

    it("does not consider zero to be null", function() {
        expect(whatToWearService.describeAppropriateClothing(0, "formal")).toBe("Wear a suit and a coat.");
    });

});
