// This is another version of the whatToWearController test suite that uses spies.
describe("whatToWearController (with spies)", function() {

    // This tells it which module we're testing.
    beforeEach(module("testingDemoModule"));

    // Declare variables here that need to be shared between all the funcitons below.
    var whatToWearController, whatToWearService, $scope;

    // use inject() to grab angular dependencies
    beforeEach(inject(function($controller) {
        // A fake (mock) whatToWearService
        whatToWearService = {
            // this mock method will always return "Wear this."
            describeAppropriateClothing: jasmine.createSpy("describeAppropriateClothing").and.returnValue("Wear this.")
        };
        $scope = {}; // Scope starts out empty
        // Create the controller. Specify the dependencies to inject.
        whatToWearController = $controller('whatToWearController', {
            $scope: $scope,
            whatToWearService: whatToWearService
        });
    }));

    it("starts out with default", function() {
        // Verify that the result of describeAppropriateClothing was set to the output
        expect($scope.output).toBe("Wear this.");
        // Verify that describeAppropriateClothing was actually called with the expected parameters.
        expect(whatToWearService.describeAppropriateClothing).toHaveBeenCalledWith(72, "casual");
    });

    it("updates output when temperature changes", function() {
        $scope.temperature = 60;
        whatToWearService.describeAppropriateClothing.and.returnValue("Wear that.");
        $scope.updateTemperature();
        expect($scope.output).toBe("Wear that.");
        expect(whatToWearService.describeAppropriateClothing).toHaveBeenCalledWith(60, "casual");
    });

    it("updates output when event type changes", function() {
        $scope.eventType = 'formal';
        whatToWearService.describeAppropriateClothing.and.returnValue("Wear that.");
        $scope.updateEventType();
        expect($scope.output).toBe("Wear that.");
        expect(whatToWearService.describeAppropriateClothing).toHaveBeenCalledWith(72, "formal");
    });

});
