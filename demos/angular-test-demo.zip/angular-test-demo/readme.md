# Testing with Angular
A demonstration of testing with Angular, Jasmine and Karma.

### Run it!
1. From the terminal run `npm install`. This will install all the dependencies in
   package.json, including karma, jasmine and angular mock. You only need to do
   this once.
2. Run `karma start`. This will run the tests and keep running them every time
   you save any files.

### Have a look around.
The `script` directory contains all the main application JavaScript files. The `tests` directory contains all the tests.

Start with `whatToWearController` and `whatToWearService`. These are a relatively simple controller and service pair, working together.

Now have a look at `whatToWearService.spec.js`. This is the simplest test to start out with. Of course, the tests in this file test `whatToWearService`.

Next check out `whatToWearController.spec.js`. This tests the `whatToWearController`. Testing controllers is a bit more complicated than testing services.

To take it to the next level, `whatToWearController.spies.spec.js` performs the same tests again but makes use of Jasmine *spies*. In this case, it's a different way of making the same tests, but it does not rely on the real `whatToWearService`.

Finally, if you're feeling brave, venture into `whatToWearAtLocationController` and `whatToWearAtLocationController.spec.js`. These are quite a bit more complicated because they rely on promises and asynchronous behavior.

### Configuration
In order to set this all up we need two files:

1. `package.json` - You've seen this before. It just holds our npm project
   definition and, importantly, our *dependencies*. These dependencies get downloaded when we run `npm install`. You'll notice a few:
   * `angular` - When the tests run, they need the core Angular library.
   * `angular-mocks` - We need this extra code when testing Angular.
   * `jasmine-core` - Jasmine test framework
   * `karma` - Karma test runner
   * `karma-jasmine` - Allows Karma to work with Jasmine
   * `karma-phantomjs-launcher` - Karma needs to run the tests in a browser. This library lets Karma run them in the Phantom JS browser.
2. `karma.conf.js` - Lots of configuration for Karma. Things like:
   * What JavaScript files to use.
   * That we're using Jasmine.
   * That the tests should be run on Phantom JS.
   * That it should watch for changes and keep running the tests.

### See also
[Jasmine docs](https://jasmine.github.io/2.5/introduction.html)

[Angular Unit Testing docs](https://docs.angularjs.org/guide/unit-testing)

[Angular's own testing example](https://github.com/angular/angular-seed)

What if your services have dependencies that need mocked? Use `module` and `$provide` [like this](https://www.sitepoint.com/mocking-dependencies-angularjs-tests/).
