(function() { // <-- It's an IIFE
var app = angular.module("megaApp", []); // create the module

// TODO Set up routing.

// #!/madlib --> madlib.html views

// #!/band --> band-members.html view and bandMembersController

// Otherwise, display "Please select one of the links above."



})();
